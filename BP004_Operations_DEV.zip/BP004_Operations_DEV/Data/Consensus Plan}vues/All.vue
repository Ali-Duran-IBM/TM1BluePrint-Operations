﻿389,100
390,"All"
370,0
361,1
362,1
363,0
364,0
365,0
366,0
367,0
376,1
375,c:0.00
374,7
7,Location
6,All Members
7,Product
6,All Members
7,Source
270,0
274,
275,16
[Source].MEMBERS
281,0
282,
7,Versions
6,All Members
7,Original Adjusted
270,0
274,
275,27
[Original Adjusted].MEMBERS
281,0
282,
7,Product Group
6,All Members
7,BP Clients
6,All Members
360,1
7,Week
6,All Members
371,1
7,Measure
270,12
Units
Price
Cost
Weeks of Demand
Percent of Total
Gross Revenue
Cost of Sales
Gross Margin
Gross Margin Per Unit
Production Cost
Production Cost of Sales
Component Cost of Sales
274,
275,
281,0
282,
373,7
2,1011
3,10587-14121-00
3,Consensus Forecast
2,Forecast
1,Original
2,10587
1,Admin
372,0
372,00
384,0
385,0
377,4
0
0
0
0
378,0
382,255
379,9
0
0
0
0
0
0
0
0
0
11,20150510015212
381,0
