﻿389,100
390,"Consensus Plan"
370,0
361,1
362,1
363,0
364,0
365,0
366,0
367,0
376,1
375,c:0.00
374,6
7,Product Group
270,4
All Product
10587
19200
26600
274,Description
275,
281,0
282,
7,Original Adjusted
270,2
Original
Adjusted
274,
275,
281,0
282,
7,Source
270,5
Demand Planner Forecast
Statistical Forecast
Consensus Forecast
Customer Forecast
Financial Forecast
274,
275,
281,0
282,
7,Location
6,DCs
7,Measure
270,9
Units
Price
Cost
Weeks of Demand
Percent of Total
Gross Revenue
Cost of Sales
Gross Margin
Gross Margin Per Unit
274,
275,
281,0
282,
7,BP Clients
6,All Members
360,1
7,Week
6,Consensus Plan
371,2
7,Product
6,Products Only
7,Versions
6,Consensus Plan
373,6
2,10587
1,Original
3,Consensus Forecast
1,1011
1,Units
1,Admin
372,1
372,10
384,1
385,0
377,4
0
0
0
0
378,0
382,255
379,9
0
0
0
0
0
0
0
0
0
11,20150510010534
381,0
