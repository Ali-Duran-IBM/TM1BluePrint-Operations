﻿389,100
390,"Plan"
370,0
361,1
362,1
363,0
364,0
365,0
366,0
367,0
376,1
375,c:0.00
374,6
7,Measure
6,All Members
7,Source
270,0
274,
275,16
[Source].MEMBERS
281,0
282,
7,Versions
6,All Members
7,Original Adjusted
270,0
274,
275,27
[Original Adjusted].MEMBERS
281,0
282,
7,Product Group
6,All Members
7,BP Clients
6,All Members
360,2
7,Product
6,Products
7,Location
6,Temp
371,1
7,Week
6,Temp
373,6
2,Price
3,Consensus Forecast
1,Actual
1,Original
4,26600
1,Admin
372,0
372,00
384,0
385,0
377,4
0
0
0
0
378,0
382,255
379,9
0
0
0
0
0
0
0
0
0
11,20150510004224
381,0
