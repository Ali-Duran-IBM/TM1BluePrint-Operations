﻿389,100
390,"Default"
370,0
361,1
362,1
363,0
364,0
365,
366,
367,0
376,0
375,c:0.00
374,4
7,Product
270,4
All Product
10587
19200
26600
274,
275,
281,0
282,
7,Distribution Center
270,7
All Sites
1011
1063
1064
1071
1072
1079
274,
275,
281,0
282,
7,Versions
270,4
Actual
Forecast
Budget
Scenario 1
274,
275,
281,0
282,
7,BP Clients
6,All Members
360,1
7,Time
6,ALL
274,
281,0
282,
371,1
7,Inventory Plan
270,22
Beginning Inventory
Beginning Backlog (late orders)
Consensus Forecast
Actual Orders
Unconsumed Forecast
Actual Shipments
Planned Shipments
Ending Backlog (unconsumed demand and late orders)
Purchase or Production Orders
Transfer Orders
Total In Bound
Supply Adjustment
Total Supply
Ending Inventory
Standard Unit Cost
Ending Inventory Value
Optimized Safety Stock from ILOG
Inventory Budget
Inventory Variance
Weeks of Supply
Days of Supply
Turn
274,
275,
281,0
282,
373,4
1,All Product
1,All Sites
1,Actual
1,Admin
372,0
372,00
384,0
385,0
377,4
0
0
0
0
378,0
382,255
379,6
0
0
0
0
0
0
11,20150403182040
381,0
