﻿389,100
390,"Weeks of Supply"
370,0
361,1
362,1
363,0
364,0
365,
366,
367,0
376,0
375,c:0.00
374,4
7,Product
6,ALL
274,
281,0
282,
7,Distribution Center
270,7
All Sites
1011
1063
1064
1071
1072
1079
274,Description
275,
281,0
282,
7,Versions
270,4
Actual
Forecast
Budget
Scenario 1
274,
275,
281,0
282,
7,BP Clients
6,All Members
360,1
7,WOS-Weeks
270,20
W01-Y1
W02-Y1
W03-Y1
W04-Y1
W05-Y1
W06-Y1
W07-Y1
W08-Y1
W09-Y1
W10-Y1
W11-Y1
W12-Y1
W13-Y1
W14-Y1
W15-Y1
W16-Y1
W17-Y1
W18-Y1
W19-Y1
W20-Y1
274,
275,
281,0
282,
371,1
7,WOS-Measure
270,16
Ending Inventory
Consensus Forecast
CD W1
CD W2
CD W3
CD W4
CD W5
CD W6
CD W7
CD W8
CD W9
CD W10
CD W11
CD W12
CD W13
WOS
274,Description
275,
281,0
282,
373,4
3,10587-14121-00
2,1011
1,Actual
1,Admin
372,0
372,00
384,0
385,0
377,4
0
0
0
0
378,0
382,255
379,6
0
0
0
0
0
0
11,20150508044206
381,0
