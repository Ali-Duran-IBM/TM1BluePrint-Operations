﻿389,100
390,"Critical Component Constraint"
370,0
361,1
362,1
363,0
364,0
365,0
366,0
367,0
376,1
375,c:0.00
374,2
7,Versions
270,4
Actual
Forecast
Budget
Scenario 1
274,
275,
281,0
282,
7,BP Clients
6,All Members
360,2
7,Time
6,Critical Component Constraint
7,Critical Component Constraint
6,All Members
371,1
7,Critical Component Number
6,Critical Component Constraint
373,2
2,Forecast
1,Admin
372,0
372,00
384,0
385,0
377,4
0
0
0
0
378,0
382,255
379,5
0
0
0
0
0
11,20150508185140
381,0
