﻿389,100
390,"Production Requirements Summary"
370,0
361,1
362,1
363,0
364,0
365,0
366,0
367,0
376,1
375,c:0.00
374,4
7,Total Products
270,1
All Product
274,Description
275,
281,0
282,
7,Production Facilities
6,ALL
274,Description
281,0
282,
7,Versions
270,4
Actual
Forecast
Budget
Scenario 1
274,New Version
275,
281,0
282,
7,BP Clients
6,All Members
360,1
7,Time
270,17
W14-Y1
W15-Y1
W16-Y1
W17-Y1
W18-Y1
W19-Y1
W20-Y1
W21-Y1
W22-Y1
W23-Y1
W24-Y1
W25-Y1
W26-Y1
W27-Y1
W28-Y1
W29-Y1
W30-Y1
274,
275,
281,0
282,
371,1
7,Production Requirements Summary
270,9
Required Capacity - Hours
Days Worked- Standard
Days Worked Adjustment
Number of Shifts - Standard
Shift Adjustment
Hours per Shift - Standard
Shift Hours Adjustment
Production Hours Available
Hours (Over)/Under Capacity
274,
275,
281,0
282,
373,4
1,All Product
2,1011
2,Forecast
1,Admin
372,0
372,00
384,0
385,0
377,4
0
0
0
0
378,0
382,255
379,6
0
0
0
0
0
0
11,20150403182345
381,0
