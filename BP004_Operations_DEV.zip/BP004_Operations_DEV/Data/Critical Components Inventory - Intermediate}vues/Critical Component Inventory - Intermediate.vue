﻿389,100
390,"Critical Component Inventory - Intermediate"
370,0
361,1
362,1
363,0
364,0
365,0
366,0
367,0
376,1
375,c:0.00
374,5
7,Versions
270,4
Actual
Forecast
Budget
Scenario 1
274,
275,
281,0
282,
7,Critical Component Number
270,25
All Components
All Other Components
26600-74343-06
26600-74352-06
26600-74372-02
26600-74372-05
26600-74372-06
26600-74735-07
26600-76523-03
26600-76524-03
26600-77003-00
26600-80900-00
30587-34323-00
30587-34329-00
30587-34334-00
30587-34335-00
30587-34428-00
30587-34527-00
39200-00027-06
39200-00053-04
39200-00080-35
39200-00085-33
39200-00303-03
39200-00305-06
Production Cost
274,
275,
281,0
282,
7,Product
6,ALL
274,
281,0
282,
7,Production Facilities
6,ALL
274,Description
281,0
282,
7,BP Clients
6,All Members
360,1
7,Time
6,ALL
274,
281,0
282,
371,1
7,Critical Components Inventory - Intermediate
270,3
Adjusted Scheduled Production
Component Quantity
Components Consumed
274,
275,
281,0
282,
373,5
2,Forecast
3,26600-74343-06
1,All Product
1,All Sites
1,Admin
372,0
372,00
384,0
385,0
377,4
0
0
0
0
378,0
382,255
379,7
0
0
0
0
0
0
0
11,20150403144934
381,0
