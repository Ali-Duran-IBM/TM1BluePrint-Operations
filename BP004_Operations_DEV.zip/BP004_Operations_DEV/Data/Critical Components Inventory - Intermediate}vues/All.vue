﻿389,100
390,"All"
370,0
361,1
362,1
363,0
364,0
365,
366,
367,0
376,1
375,c:0.00
374,5
7,Product
6,All Members
7,Production Facilities
6,All Members
7,Versions
6,All Members
7,Critical Components Inventory - Intermediate
270,0
274,
275,54
[Critical Components Inventory - Intermediate].MEMBERS
281,0
282,
7,BP Clients
6,All Members
360,1
7,Critical Component Number
6,All Members
371,1
7,Time
6,All Members
373,5
3,10587-14121-00
3,Line 01
2,Forecast
1,Adjusted Scheduled Production
1,Admin
372,0
372,00
384,0
385,0
377,4
0
0
0
0
378,0
382,255
379,7
0
0
0
0
0
0
0
11,20150511235348
381,0
