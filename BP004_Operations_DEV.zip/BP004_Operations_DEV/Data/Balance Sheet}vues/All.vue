﻿389,100
390,"All"
370,0
361,1
362,1
363,0
364,0
365,
366,
367,0
376,1
375,c:0.00
374,5
7,Years
6,All Members
7,Versions
6,All Members
7,Months
6,All Members
7,Balance Sheet
6,All Members
7,BP Clients
6,All Members
360,1
7,Balance Sheet Change
6,All Changes
371,1
7,Organization
6,All Members
373,5
1,FY1
1,Actual
1,Dec-PY
1,Assets:
1,Admin
372,0
372,00
384,0
385,0
377,4
0
0
0
0
378,0
382,255
379,7
0
0
0
0
0
0
0
11,20150511154026
381,0
