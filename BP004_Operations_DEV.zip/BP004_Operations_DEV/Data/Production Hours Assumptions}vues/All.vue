﻿389,100
390,"All"
370,0
361,1
362,1
363,0
364,0
365,
366,
367,0
376,1
375,c:0.00
374,1
7,BP Clients
6,All Members
360,1
7,Production Hours Assumption
6,All Members
371,1
7,Production Facilities
6,All Members
373,1
1,Admin
372,0
372,00
384,0
385,0
377,4
0
0
0
0
378,0
382,255
379,3
0
0
0
11,20150508031607
381,0
