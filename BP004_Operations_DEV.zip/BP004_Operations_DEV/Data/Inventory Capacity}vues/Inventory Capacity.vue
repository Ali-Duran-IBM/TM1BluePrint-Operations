﻿389,100
390,"Inventory Capacity"
370,0
361,1
362,1
363,0
364,0
365,
366,
367,0
376,1
375,c:0.00
374,3
7,Versions
6,All Members
7,BP Clients
6,All Members
7,Inventory Capacity
6,All Members
360,1
7,Distribution Center
6,All Members
371,1
7,Product
6,All Members
373,3
1,Actual
1,Admin
1,Inventory Capacity
372,0
372,00
384,0
385,0
377,4
0
0
0
0
378,0
382,255
379,5
0
0
0
0
0
11,20150428165319
381,0
