﻿389,100
390,"Charlotte Re-Balance"
370,0
361,1
362,1
363,0
364,0
365,
366,
367,0
376,1
375,c:0.00
374,4
7,Product
6,Products Only
7,Distribution Center
270,6
1011
1063
1064
1071
1072
1079
274,Description
275,
281,0
282,
7,Versions
6,ALL
274,
281,0
282,
7,BP Clients
6,All Members
360,1
7,Time
270,21
W10-Y1
W11-Y1
W12-Y1
W13-Y1
W14-Y1
W15-Y1
W16-Y1
W17-Y1
W18-Y1
W19-Y1
W20-Y1
W21-Y1
W22-Y1
W23-Y1
W24-Y1
W25-Y1
W26-Y1
W27-Y1
W28-Y1
W29-Y1
W30-Y1
274,
275,
281,0
282,
371,2
7,Production Facilities
270,2
Line 01
Line 05
274,Description
275,
281,0
282,
7,Production Requirements
270,10
Production Allocated
Production Required Offset by Lead Time
Required Capacity - Hours
Unit Capacity per Week
Unit (Over)/Under Capacity
Unit Adjustment
Adjusted Scheduled Production
Percent of Capacity
Cummulative Production Overage (Deficit)
Adjusted Production - (Over)/Under Capacity
274,
275,
281,0
282,
373,4
1,10587-14121-00
1,1011
2,Forecast
1,Admin
372,0
372,00
384,0
385,0
377,4
0
0
0
0
378,0
382,255
379,7
0
0
0
0
0
0
0
11,20150403182331
381,0
