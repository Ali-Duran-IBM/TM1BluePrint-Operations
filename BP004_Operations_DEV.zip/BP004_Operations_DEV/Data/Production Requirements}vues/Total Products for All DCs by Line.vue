﻿389,100
390,"Total Products for All DCs by Line"
370,0
361,1
362,1
363,0
364,0
365,
366,
367,0
376,1
375,c:0.00
374,5
7,Product
6,ALL
274,
281,0
282,
7,Distribution Center
270,7
All Sites
1011
1063
1064
1071
1072
1079
274,Description
275,
281,0
282,
7,Production Facilities
6,ALL
274,Description
281,0
282,
7,Versions
270,1
Forecast
274,
275,
281,0
282,
7,BP Clients
6,All Members
360,1
7,Time
270,13
W01-Y1
W02-Y1
W03-Y1
W04-Y1
W05-Y1
W06-Y1
W07-Y1
W08-Y1
W09-Y1
W10-Y1
W11-Y1
W12-Y1
W13-Y1
274,
275,
281,0
282,
371,1
7,Production Requirements
6,ALL
274,
281,0
282,
373,5
1,All Product
1,All Sites
3,Line 01
1,Forecast
1,Admin
372,0
372,00
384,0
385,0
377,4
0
0
0
0
378,0
382,255
379,7
0
0
0
0
0
0
0
11,20150403182331
381,0
