﻿389,100
390,"Production Hours Reconcilition"
370,0
361,1
362,1
363,0
364,0
365,0
366,0
367,0
376,1
375,c:0.00
374,5
7,Product
6,ALL
274,
281,0
282,
7,Distribution Center
270,7
All Sites
1011
1063
1064
1071
1072
1079
274,Description
275,
281,0
282,
7,Production Facilities
6,ALL
274,Description
281,0
282,
7,Versions
6,ALL
274,
281,0
282,
7,BP Clients
6,All Members
360,1
7,Time
6,ALL
274,
281,0
282,
371,1
7,Production Requirements
270,7
Days Worked- Standard
Days Worked Adjustment
Number of Shifts - Standard
Shift Adjustment
Hours per Shift - Standard
Shift Hours Adjustment
Production Hours Available
274,
275,
281,0
282,
373,5
2,10587
2,1011
3,Line 01
1,Actual
1,Admin
372,0
372,00
384,0
385,0
377,4
0
0
0
0
378,0
382,255
379,7
0
0
0
0
0
0
0
11,20150403182331
381,0
