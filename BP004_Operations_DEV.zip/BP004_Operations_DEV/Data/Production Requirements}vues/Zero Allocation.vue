﻿389,100
390,"Zero Allocation"
370,0
361,1
362,1
363,0
364,0
365,
366,
367,0
376,1
375,c:0.00
374,3
7,Production Requirements
6,Unit Adjustment
7,Versions
6,Forecast
7,BP Clients
6,All Members
360,2
7,Product
6,Products
7,Time
6,Planning Weeks
371,2
7,Distribution Center
6,Distribution Centers
7,Production Facilities
6,Production Lines Only
373,3
1,Unit Adjustment
1,Forecast
1,Admin
372,0
372,00
384,0
385,0
377,4
0
0
0
0
378,0
382,255
379,7
0
0
0
0
0
0
0
11,20150512142435
381,0
