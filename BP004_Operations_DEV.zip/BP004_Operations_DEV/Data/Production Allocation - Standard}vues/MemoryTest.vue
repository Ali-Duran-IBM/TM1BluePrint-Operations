﻿389,100
390,"MemoryTest"
370,0
361,1
362,1
363,0
364,0
365,
366,
367,0
376,1
375,c:0.00
374,3
7,Production Facilities
6,All Members
7,Production Allocation - Standard
6,All Members
7,BP Clients
6,All Members
360,1
7,Distribution Center
6,All Members
371,1
7,Product
6,All Members
373,3
1,All Sites
1,Allocation
1,Admin
372,0
372,00
384,0
385,0
377,4
0
0
0
0
378,0
382,255
379,5
0
0
0
0
0
11,20150403182203
381,0
