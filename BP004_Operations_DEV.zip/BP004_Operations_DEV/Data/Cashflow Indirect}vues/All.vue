﻿389,100
390,"All"
370,0
361,1
362,1
363,0
364,0
365,
366,
367,0
376,0
375,c:0.00
374,4
7,Versions
6,All Members
7,Months
6,All Members
7,Cashflow (Indirect Method)
6,All Members
7,BP Clients
6,All Members
360,1
7,Years
6,All Members
371,1
7,Organization
6,All Members
373,4
1,Actual
1,Dec-PY
1,Cash flows from operating activities:
1,Admin
372,0
372,00
384,0
385,0
377,4
0
0
0
0
378,0
382,255
379,6
0
0
0
0
0
0
11,20150512142452
381,0
