﻿389,100
390,"ICube_}Link_Critical Component BOM to Bill of Materials"
370,0
361,1
362,1
363,0
364,0
365,
366,
367,0
376,1
375,c:0.00
374,4
7,Product
6,All Members
7,Critical Components
6,All Members
7,Versions
6,All Members
7,Component Measures
6,All Members
360,1
7,BP Clients
6,All Members
371,1
7,Critical Component Number
6,All Members
373,4
3,10587-14121-00
2,Component 1
2,Forecast
1,Quantity
372,0
372,00
384,0
385,0
377,4
0
0
0
0
378,0
382,255
379,6
0
0
0
0
0
0
11,20150508133518
381,0
