﻿389,100
390,"MemoryTest"
370,0
361,1
362,1
363,0
364,0
365,
366,
367,0
376,1
375,c:0.00
374,4
7,Production Facilities
6,All Members
7,Product
6,All Members
7,Distribution Center
6,All Members
7,BP Clients
6,All Members
360,2
7,Versions
6,All Members
7,Production Required for Offset
270,0
274,
275,40
[Production Required for Offset].MEMBERS
281,0
282,
371,1
7,Time for Offset
270,0
274,
275,25
[Time for Offset].MEMBERS
281,0
282,
373,4
1,All Sites
1,All Product
1,All Sites
1,Admin
372,0
372,00
384,0
385,0
377,4
0
0
0
0
378,0
382,255
379,7
0
0
0
0
0
0
0
11,20150403182310
381,0
